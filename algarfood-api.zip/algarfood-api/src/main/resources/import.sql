insert into cozinha (nome) values ('Indiana');
insert into cozinha (nome) values ('Mexicana');

insert into estado (nome) values ('São Paulo');
package com.algaworks.algafood.api.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.algaworks.algafood.domain.model.Cozinha;
import com.algaworks.algafood.domain.service.CozinhaServices;

@RestController
@RequestMapping("/api/cozinhas/")
public class CozinhaController {

//	@Autowired
//	private CozinhaRepository cozinhaRepository;
	
	@Autowired
	private CozinhaServices cozinhaServices;
	
	@GetMapping
	public List<Cozinha> getCozinhas() {
		return cozinhaServices.buscaCozinhas();
	}
	
	@GetMapping("{id}")
	public ResponseEntity<Cozinha> getCozinha(@PathVariable Long id) {
		Cozinha cozinha = cozinhaServices.buscaCozinha(id);
		
		if (cozinha != null)
			return ResponseEntity.ok(cozinha);
		
		return ResponseEntity.notFound().build();
	}
	
	@PostMapping
	@ResponseStatus(HttpStatus.CREATED)
	public Cozinha incluiCozinha(@RequestBody Cozinha cozinha){
		return cozinhaServices.incluiCozinha(cozinha);
	}
	
	@PutMapping("{id}")
	public ResponseEntity<Cozinha> alteraCozinha(@PathVariable Long id, @RequestBody Cozinha cozinhaPut) {

		Cozinha cozinha = cozinhaServices.alteraCozinha(id, cozinhaPut);

		if (cozinha == null)
			return ResponseEntity.notFound().build();
		
		return ResponseEntity.ok(cozinha);
	}

	@DeleteMapping("{id}")
	public ResponseEntity<Cozinha> deleteCozinha(@PathVariable Long id) {

		try {
			Boolean cozinhaDeletada = cozinhaServices.deleteCozinha(id);
			if (cozinhaDeletada)
				return ResponseEntity.noContent().build();

			return ResponseEntity.notFound().build();

		} catch (DataIntegrityViolationException e) {
			return ResponseEntity.status(HttpStatus.CONFLICT).build();
		}

	}

}

package com.algaworks.algafood.domain.service;

import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.algaworks.algafood.domain.model.Cozinha;
import com.algaworks.algafood.domain.repository.CozinhaRepository;

@Service
public class CozinhaServices {
	
	@Autowired 
	private CozinhaRepository cozinhaRepository;
	
	public Cozinha incluiCozinha(Cozinha cozinha) {
		return cozinhaRepository.save(cozinha);
	}
	
	public List<Cozinha> buscaCozinhas(){
		return cozinhaRepository.findAll();
	}
	
	public Cozinha buscaCozinha(Long id) {
		return cozinhaRepository.findById(id).orElse(null);
	}
	
	public Cozinha alteraCozinha(Long id, Cozinha cozinhaAlterada) {
		
		Cozinha cozinha = cozinhaRepository.findById(id).orElse(null);
		if (cozinha == null)
			return null;
		
		BeanUtils.copyProperties(cozinhaAlterada, cozinha, "id");
		
		return cozinhaRepository.saveAndFlush(cozinha);
		
	}
	
	public Boolean deleteCozinha(Long id) {

		Cozinha cozinha = cozinhaRepository.findById(id).orElse(null);
		if (cozinha == null)
			return false;

		cozinhaRepository.deleteById(id);
		return true;

	}
	
}

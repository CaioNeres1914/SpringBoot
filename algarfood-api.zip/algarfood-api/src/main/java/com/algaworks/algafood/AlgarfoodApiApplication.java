package com.algaworks.algafood;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AlgarfoodApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(AlgarfoodApiApplication.class, args);
	}

}
